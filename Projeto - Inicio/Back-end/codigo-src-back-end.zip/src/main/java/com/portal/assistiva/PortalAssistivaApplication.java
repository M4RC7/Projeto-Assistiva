package com.portal.assistiva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortalAssistivaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortalAssistivaApplication.class, args);
	}

}
